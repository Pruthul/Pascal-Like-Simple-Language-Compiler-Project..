Pascal-Like-Simple-Language-Compiler-Project

Language: C++

The compiler was three-part project consisting of a lexical analyzer, parser, and interpreter with grammar
rules of the language and syntax rules already set.

It is designed such that it compiles the given code and throws back any error- syntax, compiler, logical, etc.
like a functioning compiler.

© Pruthul Patel | 2022 | NJIT
